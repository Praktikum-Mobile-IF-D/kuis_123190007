package com.example.kuis_praktikummobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
